// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

package com.microsoft.aad.msal4j;

import java.util.List;
import java.util.Map;
import java.util.Set;

class IntegratedWindowsAuthorizationGrant extends AbstractMsalAuthorizationGrant {

    private final String userName;

    IntegratedWindowsAuthorizationGrant(Set<String> scopes, String userName, ClaimsRequest claims) {
        this.userName = userName;
        this.scopes = scopes;
        this.claims = claims;
    }

    @Override
    Map<String, String> toParameters() {
        return null;
    }

    String getUserName() {
        return userName;
    }
}
